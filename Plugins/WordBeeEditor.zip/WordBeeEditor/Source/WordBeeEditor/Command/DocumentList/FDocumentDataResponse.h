#pragma once

struct FDocumentDataResponse
{
	
	FString Name;
	FString Id;

	FString DtChange;

	int32 Did;

	FString Src;

	FString SrcT;

	int32 Paragraphs;

	int32 Segments;

	int32 Pid;

	FString Connector;

	FString Preference;

	int32 PStatus;

	FString PStatusT;

	FString FilterName;
};
