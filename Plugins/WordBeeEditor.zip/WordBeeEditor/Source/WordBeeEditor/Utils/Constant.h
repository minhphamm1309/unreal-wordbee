#pragma once

#define LOGDEBUG(...) UE_LOG(LogTemp, Log, TEXT(...))
#define LOGERROR(x) UE_LOG(LogTemp, Error, TEXT(x))


class Constant
{
public:
	
};
