#pragma once

#include "CoreMinimal.h"

class Constants
{
public:
    // Plugin Asset Paths
    static const FString UserDataPath;
    static const FString DocumentDataPath;
};
