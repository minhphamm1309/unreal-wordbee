#pragma once
#include "WordBeeEditor/Models/FRecord.h"

class LocalizeUtil
{
public:
	LocalizeUtil() {  }
	TArray<FRecord> RecordsChanged; 
};
