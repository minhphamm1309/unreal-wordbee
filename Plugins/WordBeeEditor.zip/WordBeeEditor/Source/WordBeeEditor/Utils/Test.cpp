#include "Test.h"
#include "CoreMinimal.h"
#include "Locate.h"
#include "SingletonUtil.h"
#include "WordBeeEditor/Models/FEditorConfig.h"

void Test::Ttessttt()
{
	//Locate<LocalizeUtil>::Get();
	//auto	Config = wordbee::SingletonUtil<FEditorConfig>::GetFromIni();
}
