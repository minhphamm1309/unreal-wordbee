#pragma once

class Test
{
public:
	void Ttessttt();
};
