#pragma once

class WordbeeUtils
{
public:
	static TArray<FString> EnumToStringArray(UEnum* EnumClass);
};
